module.exports = {
    client: {
        name: 'Space Explorer [web]',
        service: 'space-explorer',
    },
};