const baseUrl = {
    local: "http://localhost:5000/graphql",
    server: 'http://3.15.200.171:5000/graphql',
    socket: "http://3.15.200.171:5000/",
}
module.exports = { baseUrl };
