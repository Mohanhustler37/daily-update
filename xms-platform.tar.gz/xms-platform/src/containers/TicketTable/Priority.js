import React,{Component} from "react";
import "./Priority.css";

class Priority extends Component{
    constructor(props){
        super(props)
    }
    render(){
        return(
            <div></div>
        )
    }
}